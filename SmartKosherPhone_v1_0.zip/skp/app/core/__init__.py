# BluePhone core managers
